
The Coroner's Toolkit (aka TCT) was written by myself and my erstwhile
collegue, Wietse Venema, and was originally released (I think? :))
in 1999. This is fossil ware, basically :)

I might claim that it was the first foray into the more serious
field of computer forensics, which until that time had been a bit
mired in dd'ing disks and that sort of thing.

Looking at the bibliography that we shipped with it... there were
zero books on Forensic Computing even written, just scraps and 
pieces from other disciplines... that sure changed fast ;)

I guess my main things in here were Lazarus (invented data carving
and gave the first ray of hope to recovering lost data on UNIX/Linux
style systems; basically wrote it over a weekend with a bit of
insight) & MACtimes. Wietse did all the hard C stuff, and ported
file(1) for my pathetically slow Laz.

Brian Carrier took TCT and created Sleuthkit from it; I'd advise you
to seek out his stuff or other tools for modern forensic challenges....

